create env
'''bash
conda create -n wineq python=3.7
'''

activate env
'''bash
conda activate wineq
'''

install the requirements
'''bash
pip install -r requirements.txt
'''